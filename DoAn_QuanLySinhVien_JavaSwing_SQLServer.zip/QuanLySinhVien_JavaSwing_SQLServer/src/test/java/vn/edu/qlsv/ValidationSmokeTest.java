package vn.edu.qlsv;

import vn.edu.qlsv.util.Validate;
import java.math.BigDecimal;
import java.sql.Date;

/** Không yêu cầu JUnit/Maven; chạy thuần JDK để tự kiểm thử logic đầu vào. */
public class ValidationSmokeTest {
    private static int passed;
    public static void main(String[] args) {
        check("required", () -> eq("SV001", Validate.required(" SV001 ", "Mã", 10)));
        reject("blank required", () -> Validate.required("  ", "Mã", 10));
        reject("max length", () -> Validate.required("ABCDEF", "Mã", 5));
        check("date", () -> eq(Date.valueOf("2005-01-12"), Validate.dateOrNull("2005-01-12")));
        reject("invalid date", () -> Validate.dateOrNull("2026-02-31"));
        check("empty date", () -> eq(null, Validate.dateOrNull("")));
        check("score zero", () -> eq(new BigDecimal("0"), Validate.scoreOrNull("0", "Điểm")));
        check("score 10", () -> eq(new BigDecimal("10"), Validate.scoreOrNull("10", "Điểm")));
        check("score decimal comma", () -> eq(new BigDecimal("8.5"), Validate.scoreOrNull("8,5", "Điểm")));
        reject("score too high", () -> Validate.scoreOrNull("10.01", "Điểm"));
        reject("score too precise", () -> Validate.scoreOrNull("7.888", "Điểm"));
        check("credit > 0", () -> eq(3, Validate.positiveInt("3", "Số tín chỉ")));
        reject("credit zero", () -> Validate.positiveInt("0", "Số tín chỉ"));
        check("academic year", () -> eq("2026-2027", Validate.academicYear("2026-2027")));
        reject("invalid year", () -> Validate.academicYear("26-27"));
        System.out.println("PASS: " + passed + "/15 logic checks.");
    }
    private static void eq(Object expected, Object actual) {
        if (!java.util.Objects.equals(expected, actual))
            throw new AssertionError("Expected " + expected + " but was " + actual);
    }
    private static void check(String name, Runnable fn) {
        fn.run(); passed++; System.out.println("OK " + name);
    }
    private static void reject(String name, Runnable fn) {
        try { fn.run(); throw new AssertionError("Expected validation error: " + name); }
        catch (IllegalArgumentException expected) { passed++; System.out.println("OK rejected " + name); }
    }
}
