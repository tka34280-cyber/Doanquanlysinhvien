package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Sql;
import vn.edu.qlsv.util.Validate;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class SinhVienFrame extends CrudFrame {
    private final JTextField ma = Ui.input();
    private final JTextField ten = Ui.input();
    private final JTextField ngay = Ui.input();
    private final JComboBox<String> gioiTinh = new JComboBox<>(new String[]{"(Không chọn)", "Nam", "Nữ", "Khác"});
    private final JTextField diaChi = Ui.input();
    private final JTextField soDT = Ui.input();
    private final JComboBox<Sql.Option> lop = new JComboBox<>();

    public SinhVienFrame() {
        super("FORM 2 • QUẢN LÝ SINH VIÊN", new String[]{"Mã SV", "Họ tên", "Ngày sinh", "Giới tính",
                "Địa chỉ", "Số điện thoại", "Mã lớp", "Tên lớp"});
        JPanel panel = Ui.editor();
        Ui.field(panel, 0, 0, "Mã sinh viên *", ma);
        Ui.field(panel, 0, 1, "Họ tên *", ten);
        Ui.field(panel, 1, 0, "Ngày sinh", ngay);
        Ui.field(panel, 1, 1, "Giới tính", gioiTinh);
        Ui.field(panel, 2, 0, "Địa chỉ", diaChi);
        Ui.field(panel, 2, 1, "Số điện thoại", soDT);
        Ui.field(panel, 3, 0, "Lớp học *", lop);
        build(panel, "Ngày sinh: yyyy-MM-dd  |  Hãy thêm lớp trước khi thêm sinh viên");
        reload();
    }

    @Override protected int onLoad() throws SQLException {
        Sql.fillOptions(lop, "SELECT MaLop, TenLop FROM dbo.LOP ORDER BY MaLop");
        String sql = "SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.DiaChi, "
                + "sv.SoDienThoai, sv.MaLop, l.TenLop FROM dbo.SINHVIEN sv "
                + "JOIN dbo.LOP l ON sv.MaLop=l.MaLop "
                + "WHERE sv.MaSV LIKE ? OR sv.HoTen LIKE ? OR l.TenLop LIKE ? ORDER BY sv.MaSV";
        String k = keyword();
        return Sql.fillTable(model, sql, k, k, k);
    }

    @Override protected void onSelected(int row) {
        ma.setText(value(row, 0));
        ten.setText(value(row, 1));
        ngay.setText(value(row, 2));
        String gender = value(row, 3);
        gioiTinh.setSelectedItem(gender.isEmpty() ? "(Không chọn)" : gender);
        diaChi.setText(value(row, 4));
        soDT.setText(value(row, 5));
        Sql.selectOption(lop, value(row, 6));
        ma.setEditable(false);
    }

    @Override protected void onClear() {
        ma.setEditable(true);
        ma.setText(""); ten.setText(""); ngay.setText("");
        gioiTinh.setSelectedIndex(0);
        diaChi.setText(""); soDT.setText("");
        if (lop.getItemCount() > 0) lop.setSelectedIndex(0);
        ma.requestFocusInWindow();
    }

    @Override protected void onCreate() throws SQLException {
        Sql.execute("INSERT INTO dbo.SINHVIEN "
                + "(MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,MaLop) VALUES (?,?,?,?,?,?,?)",
                Validate.required(ma.getText(), "Mã sinh viên", 10),
                Validate.required(ten.getText(), "Họ tên", 100),
                Validate.dateOrNull(ngay.getText()), selectedGender(),
                Validate.optional(diaChi.getText(), "Địa chỉ", 200),
                Validate.optional(soDT.getText(), "Số điện thoại", 15),
                Validate.requiredChoice(Sql.chosenId(lop), "lớp học"));
    }

    @Override protected void onUpdate() throws SQLException {
        Sql.execute("UPDATE dbo.SINHVIEN SET HoTen=?, NgaySinh=?, GioiTinh=?, DiaChi=?, "
                + "SoDienThoai=?, MaLop=? WHERE MaSV=?",
                Validate.required(ten.getText(), "Họ tên", 100),
                Validate.dateOrNull(ngay.getText()), selectedGender(),
                Validate.optional(diaChi.getText(), "Địa chỉ", 200),
                Validate.optional(soDT.getText(), "Số điện thoại", 15),
                Validate.requiredChoice(Sql.chosenId(lop), "lớp học"), ma.getText().trim());
    }

    @Override protected void onDelete() throws SQLException {
        Sql.execute("DELETE FROM dbo.SINHVIEN WHERE MaSV=?", ma.getText().trim());
    }

    private String selectedGender() {
        return gioiTinh.getSelectedIndex() <= 0 ? null : (String) gioiTinh.getSelectedItem();
    }
}
