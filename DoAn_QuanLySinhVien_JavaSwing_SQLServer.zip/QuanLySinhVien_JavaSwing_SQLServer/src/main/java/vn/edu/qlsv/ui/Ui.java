package vn.edu.qlsv.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public final class Ui {
    public static final Color NAVY = new Color(24, 45, 79);
    public static final Color BLUE = new Color(35, 105, 184);
    public static final Color BG = new Color(242, 246, 251);
    public static final Color WHITE = Color.WHITE;
    private Ui() { }

    public static JPanel editor() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(WHITE);
        panel.setBorder(new EmptyBorder(15, 18, 15, 18));
        return panel;
    }

    public static void field(JPanel panel, int row, int col, String caption, JComponent component) {
        GridBagConstraints label = new GridBagConstraints();
        label.gridx = col * 2;
        label.gridy = row;
        label.insets = new Insets(6, 7, 6, 7);
        label.anchor = GridBagConstraints.WEST;
        JLabel text = new JLabel(caption);
        text.setForeground(NAVY);
        text.setFont(text.getFont().deriveFont(Font.BOLD, 12f));
        panel.add(text, label);
        GridBagConstraints input = new GridBagConstraints();
        input.gridx = col * 2 + 1;
        input.gridy = row;
        input.insets = new Insets(6, 7, 6, 20);
        input.weightx = 1;
        input.fill = GridBagConstraints.HORIZONTAL;
        component.setPreferredSize(new Dimension(220, 28));
        panel.add(component, input);
    }

    public static JTextField input() {
        JTextField tf = new JTextField();
        tf.setFont(tf.getFont().deriveFont(13f));
        return tf;
    }

    public static JButton button(String text, boolean prominent) {
        JButton b = new JButton(text);
        b.setFont(b.getFont().deriveFont(Font.BOLD, 12f));
        b.setFocusable(false);
        b.setBackground(prominent ? BLUE : WHITE);
        b.setForeground(prominent ? WHITE : NAVY);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(prominent ? BLUE : new Color(195, 204, 217)),
                new EmptyBorder(8, 16, 8, 16)));
        b.setOpaque(true);
        b.setHorizontalAlignment(SwingConstants.CENTER);
        return b;
    }
}
