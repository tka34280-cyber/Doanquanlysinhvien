package vn.edu.qlsv.db;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;

public final class Sql {
    private Sql() { }

    public record Option(String id, String label) {
        @Override public String toString() { return id + " — " + label; }
    }

    public static int execute(String sql, Object... args) throws SQLException {
        try (Connection conn = Database.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, args);
            return ps.executeUpdate();
        }
    }

    public static int fillTable(DefaultTableModel model, String sql, Object... args) throws SQLException {
        try (Connection conn = Database.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, args);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int columns = meta.getColumnCount();
                int total = 0;
                model.setRowCount(0);
                while (rs.next()) {
                    Object[] row = new Object[columns];
                    for (int i = 0; i < columns; i++) {
                        Object value = rs.getObject(i + 1);
                        row[i] = value instanceof BigDecimal number ? number.toPlainString() : value;
                    }
                    model.addRow(row);
                    total++;
                }
                return total;
            }
        }
    }

    public static void fillOptions(JComboBox<Option> combo, String sql) throws SQLException {
        String previous = chosenId(combo);
        DefaultComboBoxModel<Option> model = new DefaultComboBoxModel<>();
        try (Connection conn = Database.connect(); PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) model.addElement(new Option(rs.getString(1).trim(), rs.getString(2)));
        }
        combo.setModel(model);
        selectOption(combo, previous);
    }

    public static String chosenId(JComboBox<Option> combo) {
        Object chosen = combo.getSelectedItem();
        return chosen instanceof Option opt ? opt.id() : null;
    }

    public static void selectOption(JComboBox<Option> combo, String id) {
        if (id == null) return;
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (id.trim().equals(combo.getItemAt(i).id())) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private static void bind(PreparedStatement ps, Object... args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            if (args[i] == null) ps.setNull(i + 1, Types.NULL);
            else ps.setObject(i + 1, args[i]);
        }
    }
}
