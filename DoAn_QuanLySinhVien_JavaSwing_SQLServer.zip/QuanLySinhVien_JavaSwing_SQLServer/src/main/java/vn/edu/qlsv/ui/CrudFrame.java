package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Database;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;

public abstract class CrudFrame extends JFrame {
    protected final DefaultTableModel model;
    protected final JTable table;
    protected final JTextField search = Ui.input();
    private final JLabel info = new JLabel("Sẵn sàng");

    protected CrudFrame(String title, String[] columns) {
        super(title);
        model = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.getTableHeader().setReorderingAllowed(false);
        table.setFillsViewportHeight(true);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                onSelected(table.convertRowIndexToModel(table.getSelectedRow()));
            }
        });
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(920, 560));
        setSize(1170, 740);
        setLocationRelativeTo(null);
    }

    protected final void build(JPanel editor, String hint) {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(Ui.BG);
        root.setBorder(new EmptyBorder(13, 16, 13, 16));

        JPanel header = new JPanel(new BorderLayout(12, 6));
        header.setOpaque(false);
        JLabel heading = new JLabel(getTitle());
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 23f));
        heading.setForeground(Ui.NAVY);
        header.add(heading, BorderLayout.NORTH);

        JPanel find = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        find.setOpaque(false);
        find.add(new JLabel("Tìm theo mã hoặc tên:"));
        search.setPreferredSize(new Dimension(260, 28));
        find.add(search);
        JButton bSearch = Ui.button("TÌM KIẾM", true);
        JButton bAll = Ui.button("HIỆN TẤT CẢ", false);
        find.add(bSearch);
        find.add(bAll);
        bSearch.addActionListener(e -> reload());
        search.addActionListener(e -> reload());
        bAll.addActionListener(e -> { search.setText(""); reload(); });
        header.add(find, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        editor.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new java.awt.Color(211, 219, 231)),
                " THÔNG TIN NHẬP LIỆU "));
        JScrollPane editorScroll = new JScrollPane(editor);
        editorScroll.getVerticalScrollBar().setUnitIncrement(16);
        JScrollPane gridScroll = new JScrollPane(table);
        gridScroll.setBorder(BorderFactory.createTitledBorder(" DANH SÁCH DỮ LIỆU "));
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, editorScroll, gridScroll);
        split.setResizeWeight(0.45);
        split.setDividerLocation(275);
        root.add(split, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout(4, 8));
        footer.setOpaque(false);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 0));
        actions.setOpaque(false);
        JButton add = Ui.button("+ THÊM", true);
        JButton edit = Ui.button("SỬA", false);
        JButton del = Ui.button("XÓA", false);
        JButton clear = Ui.button("LÀM MỚI FORM", false);
        JButton refresh = Ui.button("TẢI LẠI DỮ LIỆU", false);
        actions.add(add);
        actions.add(edit);
        actions.add(del);
        actions.add(clear);
        actions.add(refresh);
        footer.add(actions, BorderLayout.NORTH);
        JPanel footerText = new JPanel(new BorderLayout());
        footerText.setOpaque(false);
        info.setForeground(Ui.NAVY);
        footerText.add(info, BorderLayout.WEST);
        JLabel tip = new JLabel(hint);
        tip.setForeground(new java.awt.Color(92, 104, 117));
        footerText.add(tip, BorderLayout.EAST);
        footer.add(footerText, BorderLayout.SOUTH);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);

        add.addActionListener(e -> perform("thêm", false, () -> onCreate()));
        edit.addActionListener(e -> perform("sửa", true, () -> onUpdate()));
        del.addActionListener(e -> {
            if (!isSelected()) { notifyUser("Hãy chọn một dòng trong bảng để xóa."); return; }
            if (JOptionPane.showConfirmDialog(this,
                    "Bạn chắc chắn muốn xóa dòng đã chọn?", "Xác nhận xóa",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
                perform("xóa", true, () -> onDelete());
            }
        });
        clear.addActionListener(e -> clearSelection());
        refresh.addActionListener(e -> reload());
    }

    private void perform(String action, boolean requiresSelected, DbAction task) {
        if (requiresSelected && !isSelected()) {
            notifyUser("Hãy chọn một dòng trong bảng trước khi " + action + ".");
            return;
        }
        try {
            task.run();
            clearSelection();
            reload();
            JOptionPane.showMessageDialog(this, "Đã " + action + " dữ liệu thành công.",
                    "Hoàn thành", JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Dữ liệu không hợp lệ", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, Database.explain(ex), "Lỗi SQL Server", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void notifyUser(String s) {
        JOptionPane.showMessageDialog(this, s, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }

    protected final boolean isSelected() { return table.getSelectedRow() >= 0; }

    protected final void clearSelection() {
        table.clearSelection();
        onClear();
    }

    protected final Object cell(int row, int column) {
        Object value = model.getValueAt(row, column);
        return value == null ? null : value;
    }

    protected final String value(int row, int column) {
        Object obj = cell(row, column);
        return obj == null ? "" : obj.toString().trim();
    }

    protected final String keyword() { return "%" + search.getText().trim() + "%"; }

    protected final void reload() {
        table.clearSelection();
        onClear();
        try {
            int count = onLoad();
            info.setText("Đang hiển thị " + count + " dòng dữ liệu.");
        } catch (SQLException ex) {
            info.setText("Chưa tải được dữ liệu (SQL Server chưa kết nối).");
            JOptionPane.showMessageDialog(this, Database.explain(ex), "Không tải được dữ liệu", JOptionPane.ERROR_MESSAGE);
        }
    }

    @FunctionalInterface private interface DbAction { void run() throws Exception; }
    protected abstract int onLoad() throws SQLException;
    protected abstract void onSelected(int row);
    protected abstract void onClear();
    protected abstract void onCreate() throws SQLException;
    protected abstract void onUpdate() throws SQLException;
    protected abstract void onDelete() throws SQLException;
}
