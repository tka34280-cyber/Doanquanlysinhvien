package vn.edu.qlsv.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public final class Validate {
    private Validate() { }

    public static String required(String input, String label, int max) {
        String s = optional(input, label, max);
        if (s == null) throw new IllegalArgumentException(label + " không được bỏ trống.");
        return s;
    }

    public static String optional(String input, String label, int max) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty()) return null;
        if (s.length() > max) throw new IllegalArgumentException(label + " tối đa " + max + " ký tự.");
        return s;
    }

    public static Date dateOrNull(String input) {
        String s = optional(input, "Ngày sinh", 20);
        if (s == null) return null;
        try { return Date.valueOf(LocalDate.parse(s)); }
        catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Ngày sinh không hợp lệ. Hãy nhập theo dạng yyyy-MM-dd, ví dụ 2005-09-20.");
        }
    }

    public static int positiveInt(String input, String label) {
        try {
            int result = Integer.parseInt(required(input, label, 9));
            if (result <= 0) throw new NumberFormatException();
            return result;
        } catch (NumberFormatException ex) { throw new IllegalArgumentException(label + " phải là số nguyên lớn hơn 0."); }
    }

    public static BigDecimal scoreOrNull(String input, String label) {
        String s = optional(input, label, 30);
        if (s == null) return null;
        try {
            BigDecimal value = new BigDecimal(s.replace(',', '.'));
            if (value.compareTo(BigDecimal.ZERO) < 0 || value.compareTo(BigDecimal.TEN) > 0
                    || value.stripTrailingZeros().scale() > 2) {
                throw new NumberFormatException();
            }
            return value;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(label + " phải nằm trong khoảng 0–10, tối đa 2 chữ số thập phân.");
        }
    }

    public static String academicYear(String input) {
        String s = required(input, "Năm học", 9);
        if (!s.matches("[0-9]{4}-[0-9]{4}")) {
            throw new IllegalArgumentException("Năm học có định dạng yyyy-yyyy, ví dụ 2026-2027.");
        }
        return s;
    }

    public static String requiredChoice(String value, String label) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Hãy chọn " + label + ".");
        return value;
    }
}
