package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Sql;
import vn.edu.qlsv.util.Validate;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class DiemFrame extends CrudFrame {
    private final JComboBox<Sql.Option> sinhVien = new JComboBox<>();
    private final JComboBox<Sql.Option> monHoc = new JComboBox<>();
    private final JComboBox<String> hocKy = new JComboBox<>(new String[]{"1", "2", "3"});
    private final JTextField namHoc = Ui.input();
    private final JTextField quaTrinh = Ui.input();
    private final JTextField thi = Ui.input();
    private final JTextField tongKet = Ui.input();

    public DiemFrame() {
        super("FORM 4 • QUẢN LÝ ĐIỂM", new String[]{"Mã SV", "Họ tên", "Mã môn", "Tên môn",
                "Học kỳ", "Năm học", "Điểm quá trình", "Điểm thi", "Điểm tổng kết"});
        JPanel panel = Ui.editor();
        Ui.field(panel, 0, 0, "Sinh viên *", sinhVien);
        Ui.field(panel, 0, 1, "Môn học *", monHoc);
        Ui.field(panel, 1, 0, "Học kỳ *", hocKy);
        Ui.field(panel, 1, 1, "Năm học *", namHoc);
        Ui.field(panel, 2, 0, "Điểm quá trình", quaTrinh);
        Ui.field(panel, 2, 1, "Điểm thi", thi);
        Ui.field(panel, 3, 0, "Điểm tổng kết", tongKet);
        build(panel, "Điểm: 0–10, tối đa 2 chữ số lẻ  |  Năm học: 2026-2027");
        namHoc.setText("2026-2027");
        reload();
    }

    @Override protected int onLoad() throws SQLException {
        Sql.fillOptions(sinhVien, "SELECT MaSV, HoTen FROM dbo.SINHVIEN ORDER BY MaSV");
        Sql.fillOptions(monHoc, "SELECT MaMH, TenMH FROM dbo.MONHOC ORDER BY MaMH");
        String sql = "SELECT d.MaSV, sv.HoTen, d.MaMH, mh.TenMH, d.HocKy, d.NamHoc, "
                + "d.DiemQuaTrinh, d.DiemThi, d.DiemTongKet "
                + "FROM dbo.DIEM d JOIN dbo.SINHVIEN sv ON d.MaSV=sv.MaSV "
                + "JOIN dbo.MONHOC mh ON d.MaMH=mh.MaMH "
                + "WHERE d.MaSV LIKE ? OR sv.HoTen LIKE ? OR d.MaMH LIKE ? OR mh.TenMH LIKE ? "
                + "OR d.NamHoc LIKE ? ORDER BY d.NamHoc DESC, d.HocKy, d.MaSV, d.MaMH";
        String k = keyword();
        return Sql.fillTable(model, sql, k, k, k, k, k);
    }

    @Override protected void onSelected(int row) {
        Sql.selectOption(sinhVien, value(row, 0));
        Sql.selectOption(monHoc, value(row, 2));
        hocKy.setSelectedItem(value(row, 4));
        namHoc.setText(value(row, 5));
        quaTrinh.setText(value(row, 6));
        thi.setText(value(row, 7));
        tongKet.setText(value(row, 8));
        sinhVien.setEnabled(false);
        monHoc.setEnabled(false);
        hocKy.setEnabled(false);
        namHoc.setEditable(false);
    }

    @Override protected void onClear() {
        sinhVien.setEnabled(true);
        monHoc.setEnabled(true);
        hocKy.setEnabled(true);
        namHoc.setEditable(true);
        if (sinhVien.getItemCount() > 0) sinhVien.setSelectedIndex(0);
        if (monHoc.getItemCount() > 0) monHoc.setSelectedIndex(0);
        hocKy.setSelectedIndex(0);
        namHoc.setText("2026-2027");
        quaTrinh.setText(""); thi.setText(""); tongKet.setText("");
    }

    @Override protected void onCreate() throws SQLException {
        Sql.execute("INSERT INTO dbo.DIEM (MaSV,MaMH,HocKy,NamHoc,DiemQuaTrinh,DiemThi,DiemTongKet) "
                + "VALUES (?,?,?,?,?,?,?)",
                Validate.requiredChoice(Sql.chosenId(sinhVien), "sinh viên"),
                Validate.requiredChoice(Sql.chosenId(monHoc), "môn học"),
                Integer.parseInt((String) hocKy.getSelectedItem()),
                Validate.academicYear(namHoc.getText()),
                Validate.scoreOrNull(quaTrinh.getText(), "Điểm quá trình"),
                Validate.scoreOrNull(thi.getText(), "Điểm thi"),
                Validate.scoreOrNull(tongKet.getText(), "Điểm tổng kết"));
    }

    @Override protected void onUpdate() throws SQLException {
        Sql.execute("UPDATE dbo.DIEM SET DiemQuaTrinh=?, DiemThi=?, DiemTongKet=? "
                + "WHERE MaSV=? AND MaMH=? AND HocKy=? AND NamHoc=?",
                Validate.scoreOrNull(quaTrinh.getText(), "Điểm quá trình"),
                Validate.scoreOrNull(thi.getText(), "Điểm thi"),
                Validate.scoreOrNull(tongKet.getText(), "Điểm tổng kết"),
                Sql.chosenId(sinhVien), Sql.chosenId(monHoc),
                Integer.parseInt((String) hocKy.getSelectedItem()), namHoc.getText().trim());
    }

    @Override protected void onDelete() throws SQLException {
        Sql.execute("DELETE FROM dbo.DIEM WHERE MaSV=? AND MaMH=? AND HocKy=? AND NamHoc=?",
                Sql.chosenId(sinhVien), Sql.chosenId(monHoc),
                Integer.parseInt((String) hocKy.getSelectedItem()), namHoc.getText().trim());
    }
}
