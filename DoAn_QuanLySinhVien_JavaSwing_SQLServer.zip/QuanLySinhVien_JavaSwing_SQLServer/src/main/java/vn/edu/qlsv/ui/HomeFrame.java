package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Database;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public final class HomeFrame extends JFrame {
    public HomeFrame() {
        super("QUẢN LÝ SINH VIÊN | Java Swing + SQL Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(940, 590);
        setMinimumSize(new Dimension(760, 490));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(15, 18));
        root.setBackground(Ui.BG);
        root.setBorder(new EmptyBorder(28, 28, 28, 28));
        JPanel heading = new JPanel(new BorderLayout(0, 6));
        heading.setOpaque(false);
        JLabel title = new JLabel("HỆ THỐNG QUẢN LÝ SINH VIÊN");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 27f));
        title.setForeground(Ui.NAVY);
        heading.add(title, BorderLayout.NORTH);
        JLabel sub = new JLabel("Đồ án Java Swing  •  SQL Server  •  4 bảng: LỚP, SINH VIÊN, MÔN HỌC, ĐIỂM");
        sub.setForeground(Ui.BLUE);
        heading.add(sub, BorderLayout.SOUTH);
        root.add(heading, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(2, 2, 18, 18));
        cards.setOpaque(false);
        cards.add(card("01  QUẢN LÝ LỚP", "Mã lớp • tên lớp • khóa học • ngành học", () -> new LopFrame().setVisible(true)));
        cards.add(card("02  QUẢN LÝ SINH VIÊN", "Hồ sơ sinh viên • lớp • ngày sinh", () -> new SinhVienFrame().setVisible(true)));
        cards.add(card("03  QUẢN LÝ MÔN HỌC", "Mã môn học • tên môn • số tín chỉ", () -> new MonHocFrame().setVisible(true)));
        cards.add(card("04  QUẢN LÝ ĐIỂM", "Học kỳ • năm học • các thành phần điểm", () -> new DiemFrame().setVisible(true)));
        root.add(cards, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(8, 4));
        bottom.setOpaque(false);
        JButton test = Ui.button("KIỂM TRA KẾT NỐI SQL SERVER", true);
        test.addActionListener(e -> testConnection());
        bottom.add(test, BorderLayout.WEST);
        JLabel hint = new JLabel("Cấu hình: config.properties  |  SQL: sql/01_tao_csdl.sql", SwingConstants.RIGHT);
        hint.setForeground(Ui.NAVY);
        bottom.add(hint, BorderLayout.EAST);
        root.add(bottom, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel card(String title, String desc, Runnable action) {
        JPanel card = new JPanel(new BorderLayout(8, 9));
        card.setBackground(Ui.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new java.awt.Color(212, 223, 238)),
                new EmptyBorder(18, 19, 18, 19)));
        JLabel label = new JLabel(title);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 19f));
        label.setForeground(Ui.NAVY);
        card.add(label, BorderLayout.NORTH);
        JLabel description = new JLabel("<html>" + desc + "<br><br>Thêm · Sửa · Xóa · Tìm kiếm</html>");
        description.setForeground(new java.awt.Color(80, 96, 114));
        card.add(description, BorderLayout.CENTER);
        JButton go = Ui.button("MỞ FORM", true);
        go.addActionListener(e -> action.run());
        card.add(go, BorderLayout.SOUTH);
        return card;
    }

    private void testConnection() {
        try (Connection conn = Database.connect()) {
            DatabaseMetaData info = conn.getMetaData();
            JOptionPane.showMessageDialog(this, "KẾT NỐI THÀNH CÔNG!\n"
                    + "Cơ sở dữ liệu: " + conn.getCatalog() + "\n"
                    + "SQL Server: " + info.getDatabaseProductVersion(),
                    "SQL Server", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, Database.explain(ex), "Kết nối thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }
}
