package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Sql;
import vn.edu.qlsv.util.Validate;
import java.sql.SQLException;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class LopFrame extends CrudFrame {
    private final JTextField ma = Ui.input();
    private final JTextField ten = Ui.input();
    private final JTextField khoa = Ui.input();
    private final JTextField nganh = Ui.input();

    public LopFrame() {
        super("FORM 1 • QUẢN LÝ LỚP", new String[]{"Mã lớp", "Tên lớp", "Khóa học", "Ngành học"});
        JPanel panel = Ui.editor();
        Ui.field(panel, 0, 0, "Mã lớp *", ma);
        Ui.field(panel, 0, 1, "Tên lớp *", ten);
        Ui.field(panel, 1, 0, "Khóa học", khoa);
        Ui.field(panel, 1, 1, "Ngành học", nganh);
        build(panel, "* Bắt buộc  |  Chọn một dòng để sửa hoặc xóa");
        reload();
    }

    @Override protected int onLoad() throws SQLException {
        String sql = "SELECT MaLop, TenLop, KhoaHoc, NganhHoc FROM dbo.LOP "
                + "WHERE MaLop LIKE ? OR TenLop LIKE ? OR NganhHoc LIKE ? ORDER BY MaLop";
        String k = keyword();
        return Sql.fillTable(model, sql, k, k, k);
    }

    @Override protected void onSelected(int row) {
        ma.setText(value(row, 0));
        ten.setText(value(row, 1));
        khoa.setText(value(row, 2));
        nganh.setText(value(row, 3));
        ma.setEditable(false);
    }

    @Override protected void onClear() {
        ma.setEditable(true);
        ma.setText(""); ten.setText(""); khoa.setText(""); nganh.setText("");
        ma.requestFocusInWindow();
    }

    @Override protected void onCreate() throws SQLException {
        Sql.execute("INSERT INTO dbo.LOP (MaLop,TenLop,KhoaHoc,NganhHoc) VALUES (?,?,?,?)",
                Validate.required(ma.getText(), "Mã lớp", 10),
                Validate.required(ten.getText(), "Tên lớp", 100),
                Validate.optional(khoa.getText(), "Khóa học", 30),
                Validate.optional(nganh.getText(), "Ngành học", 100));
    }

    @Override protected void onUpdate() throws SQLException {
        Sql.execute("UPDATE dbo.LOP SET TenLop=?, KhoaHoc=?, NganhHoc=? WHERE MaLop=?",
                Validate.required(ten.getText(), "Tên lớp", 100),
                Validate.optional(khoa.getText(), "Khóa học", 30),
                Validate.optional(nganh.getText(), "Ngành học", 100),
                ma.getText().trim());
    }

    @Override protected void onDelete() throws SQLException {
        Sql.execute("DELETE FROM dbo.LOP WHERE MaLop=?", ma.getText().trim());
    }
}
