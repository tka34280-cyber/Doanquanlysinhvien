package vn.edu.qlsv.ui;

import vn.edu.qlsv.db.Sql;
import vn.edu.qlsv.util.Validate;
import java.sql.SQLException;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class MonHocFrame extends CrudFrame {
    private final JTextField ma = Ui.input();
    private final JTextField ten = Ui.input();
    private final JTextField soTC = Ui.input();

    public MonHocFrame() {
        super("FORM 3 • QUẢN LÝ MÔN HỌC", new String[]{"Mã môn", "Tên môn học", "Số tín chỉ"});
        JPanel panel = Ui.editor();
        Ui.field(panel, 0, 0, "Mã môn học *", ma);
        Ui.field(panel, 0, 1, "Tên môn học *", ten);
        Ui.field(panel, 1, 0, "Số tín chỉ *", soTC);
        build(panel, "Số tín chỉ phải là số nguyên dương");
        reload();
    }

    @Override protected int onLoad() throws SQLException {
        String k = keyword();
        return Sql.fillTable(model, "SELECT MaMH, TenMH, SoTinChi FROM dbo.MONHOC "
                + "WHERE MaMH LIKE ? OR TenMH LIKE ? ORDER BY MaMH", k, k);
    }

    @Override protected void onSelected(int row) {
        ma.setText(value(row, 0));
        ten.setText(value(row, 1));
        soTC.setText(value(row, 2));
        ma.setEditable(false);
    }

    @Override protected void onClear() {
        ma.setEditable(true);
        ma.setText(""); ten.setText(""); soTC.setText("");
        ma.requestFocusInWindow();
    }

    @Override protected void onCreate() throws SQLException {
        Sql.execute("INSERT INTO dbo.MONHOC (MaMH,TenMH,SoTinChi) VALUES (?,?,?)",
                Validate.required(ma.getText(), "Mã môn học", 10),
                Validate.required(ten.getText(), "Tên môn học", 100),
                Validate.positiveInt(soTC.getText(), "Số tín chỉ"));
    }

    @Override protected void onUpdate() throws SQLException {
        Sql.execute("UPDATE dbo.MONHOC SET TenMH=?, SoTinChi=? WHERE MaMH=?",
                Validate.required(ten.getText(), "Tên môn học", 100),
                Validate.positiveInt(soTC.getText(), "Số tín chỉ"), ma.getText().trim());
    }

    @Override protected void onDelete() throws SQLException {
        Sql.execute("DELETE FROM dbo.MONHOC WHERE MaMH=?", ma.getText().trim());
    }
}
