package vn.edu.qlsv.db;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public final class Database {
    private Database() { }

    public static Connection connect() throws SQLException {
        Path path = Path.of("config.properties").toAbsolutePath();
        if (!Files.isRegularFile(path)) {
            throw new SQLException("Chưa có config.properties tại: " + path
                    + "\nHãy sao chép config.example.properties thành config.properties, rồi nhập mật khẩu SQL Server.");
        }
        Properties props = new Properties();
        try (Reader in = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { props.load(in); }
        catch (IOException ex) { throw new SQLException("Không đọc được config.properties: " + ex.getMessage(), ex); }
        String host = get(props, "db.host", "localhost");
        String port = get(props, "db.port", "1433");
        String name = get(props, "db.name", "QuanLySinhVien");
        String login = get(props, "db.username", "sa");
        String password = props.getProperty("db.password", "");
        if (password.isBlank() || password.equals("CHANGE_ME")) {
            throw new SQLException("Chưa cấu hình db.password trong config.properties.");
        }
        try {
            int n = Integer.parseInt(port);
            if (n < 1 || n > 65535) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            throw new SQLException("db.port phải là số từ 1 đến 65535.");
        }
        if (host.contains(";") || name.contains(";") || port.contains(";")) {
            throw new SQLException("Địa chỉ/cổng/tên CSDL trong config.properties không hợp lệ.");
        }
        String url = "jdbc:sqlserver://" + host + ":" + port + ";"
                + "databaseName=" + name + ";"
                + "encrypt=" + get(props, "db.encrypt", "true") + ";"
                + "trustServerCertificate=" + get(props, "db.trustServerCertificate", "true") + ";"
                + "loginTimeout=5;";
        try { Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); }
        catch (ClassNotFoundException ex) {
            throw new SQLException("Thiếu thư viện mssql-jdbc. Hãy chạy NetBeans với dự án Maven và tải Dependencies.", ex);
        }
        return DriverManager.getConnection(url, login, password);
    }

    private static String get(Properties props, String key, String def) {
        String value = props.getProperty(key, def).trim();
        return value.isEmpty() ? def : value;
    }

    public static String explain(SQLException ex) {
        String msg = ex.getMessage() == null ? "Lỗi SQL Server không xác định." : ex.getMessage();
        if (ex.getErrorCode() == 2627 || ex.getErrorCode() == 2601) {
            return "Mã dữ liệu đã tồn tại. Hãy chọn mã khác.\n\nChi tiết: " + msg;
        }
        if (ex.getErrorCode() == 547) {
            return "Vi phạm quan hệ bảng (khóa ngoại hoặc ràng buộc CHECK)."
                    + "\nCó thể dữ liệu đang được bảng khác sử dụng hoặc giá trị không hợp lệ.\n\nChi tiết: " + msg;
        }
        if (ex.getErrorCode() == 18456) {
            return "Sai tài khoản hoặc mật khẩu SQL Server. Kiểm tra db.username và db.password.\n\nChi tiết: " + msg;
        }
        String lower = msg.toLowerCase();
        if (lower.contains("connection refused") || lower.contains("tcp/ip") || lower.contains("port 1433")) {
            return "Java không kết nối được SQL Server qua TCP/IP.\n"
                    + "1. Kiểm tra dịch vụ SQL Server (SQLEXPRESS) đang Running.\n"
                    + "2. Bật TCP/IP trong SQL Server Configuration Manager.\n"
                    + "3. Kiểm tra IPAll: TCP Dynamic Ports trống, TCP Port = 1433.\n"
                    + "4. Restart dịch vụ; thử PowerShell: Test-NetConnection localhost -Port 1433.\n\nChi tiết: " + msg;
        }
        if (lower.contains("cannot open database") || lower.contains("database") && lower.contains("does not exist")) {
            return "Không mở được CSDL QuanLySinhVien. Hãy chạy sql/01_tao_csdl.sql trong SSMS.\n\nChi tiết: " + msg;
        }
        return msg;
    }
}
