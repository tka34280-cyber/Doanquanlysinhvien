# ĐỒ ÁN QUẢN LÝ SINH VIÊN — Java Swing + Microsoft SQL Server

**Dự án Java Maven chạy trên Apache NetBeans**, triển khai theo bản báo cáo `Document18.pdf` (4 bảng LOP, SINHVIEN, MONHOC, DIEM). Phần mềm sử dụng Swing (JFrame/JTable) và JDBC để thêm, sửa, xóa, tìm kiếm dữ liệu trong SQL Server.

![Giao diện trang chủ](docs/anh_giao_dien_trang_chu.png)

> **Lưu ý về kiểm thử:** Mã Java được biên dịch thành công bằng JDK 21 (mục tiêu Java 17), đã chạy 15 bài kiểm thử logic đầu vào. Kết nối thực tế với SQL Server cần được kiểm tra trên máy đã cài SQL Server của bạn.

## 1. Các chức năng

| Form độc lập | Chức năng | Các bảng sử dụng |
|---|---|---|
| 1. Quản lý Lớp | Thêm / sửa / xóa lớp; tìm theo mã, tên lớp, ngành | LOP |
| 2. Quản lý Sinh viên | Thêm / sửa / xóa sinh viên; chọn lớp từ danh sách; tìm theo mã, tên, lớp | SINHVIEN + LOP |
| 3. Quản lý Môn học | Thêm / sửa / xóa môn học; tìm theo mã, tên | MONHOC |
| 4. Quản lý Điểm | Thêm / sửa / xóa điểm; chọn sinh viên và môn học; tìm theo mã, họ tên, năm học | DIEM + SINHVIEN + MONHOC |

Tất cả form đều có `JTextField`, `JComboBox` (khi cần), `JTable` bên trong `JScrollPane`, `DefaultTableModel`, xử lý sự kiện bằng Listener và `JOptionPane` báo lỗi/xác nhận xóa. Câu SQL dùng `PreparedStatement` để tránh SQL injection. Khi chọn một hàng, thông tin hiện lên form; mã chính không được chỉnh trực tiếp khi cập nhật.

**Riêng bảng DIEM** có khóa chính gồm `(MaSV, MaMH, HocKy, NamHoc)`: nhấn **Sửa** chỉ điều chỉnh ba cột điểm, không thay khóa. Để đổi học kỳ/năm học/môn, xóa bản ghi cũ và tạo bản ghi mới. Trường `DiemTongKet` được nhập trực tiếp (không tự tính) vì báo cáo không chỉ rõ công thức hay tỷ trọng.

## 2. Điều kiện chạy

- Windows 10/11, **Java JDK 17 trở lên** (khuyến nghị JDK 21), Apache NetBeans có hỗ trợ Maven.
- Microsoft SQL Server 2022 Express/Developer hoặc các phiên bản tương thích đã cài Database Engine.
- SQL Server Management Studio (SSMS) để chạy tệp SQL.
- Mạng Internet ở lần đầu mở dự án bằng Maven để tải `com.microsoft.sqlserver:mssql-jdbc:13.6.2.jre11` từ Maven Central. Đây là **trình điều khiển JDBC Microsoft**, không cần tự chép .jar nếu Maven tải thành công.

## 3. Tạo cơ sở dữ liệu

1. Mở SSMS, chọn **Server Name** tương ứng instance, thường là `localhost\SQLEXPRESS`, đăng nhập bằng Windows Authentication hoặc SQL Server Authentication.
2. Bấm **New Query → File → Open**, mở `sql/01_tao_csdl.sql`, nhấn **Execute / F5**. Script tạo database `QuanLySinhVien` cùng bốn bảng và các khóa ngoại, không xóa dữ liệu đang có.
3. (Tùy chọn) Mở `sql/02_du_lieu_mau.sql`, nhấn **F5** để nạp dữ liệu giả lập. Dữ liệu mẫu chỉ thêm bản ghi chưa có, chạy lặp lại không tạo trùng mã.
4. Mở `sql/03_kiem_tra.sql`, nhấn **F5**, kiểm tra số bản ghi và khóa ngoại.
5. Trong Object Explorer, nhấn phải **Databases → Refresh** và mở `QuanLySinhVien → Tables`.

Cấu trúc bảng lấy từ báo cáo:

- **LOP** `(MaLop PK, TenLop, KhoaHoc, NganhHoc)`.
- **SINHVIEN** `(MaSV PK, HoTen, NgaySinh, GioiTinh, DiaChi, SoDienThoai, MaLop FK→LOP)`.
- **MONHOC** `(MaMH PK, TenMH, SoTinChi > 0)`.
- **DIEM** `(MaSV FK, MaMH FK, HocKy 1–3, NamHoc, DiemQuaTrinh, DiemThi, DiemTongKet)`, khóa chính ghép `(MaSV, MaMH, HocKy, NamHoc)`, các điểm có thể để trống và phải từ 0 đến 10 khi được nhập.

## 4. Cấu hình kết nối Java (bắt buộc)

1. Tại thư mục gốc dự án (nơi có `pom.xml`), tạo một bản sao file `config.example.properties` và **đổi tên bản sao thành `config.properties`**.
2. Mở `config.properties`, sửa `db.password` thành mật khẩu `sa` của SQL Server trên máy bạn. Nếu có tài khoản SQL Server riêng cho ứng dụng, đổi cả `db.username`.
3. Để nguyên `db.host=localhost`, `db.port=1433`, `db.name=QuanLySinhVien` **chỉ khi instance của bạn đang nghe trên đúng cổng 1433**.

Ví dụ (tuyệt đối không đăng mật khẩu thật lên GitHub):

```properties
db.host=localhost
db.port=1433
db.name=QuanLySinhVien
db.username=sa
db.password=MAT_KHAU_THAT_CUA_BAN
db.encrypt=true
db.trustServerCertificate=true
```

Dùng `sa` chỉ thuận tiện để thử nghiệm trên máy cá nhân. Khi triển khai thật, hãy tạo SQL login riêng chỉ có quyền cần thiết đối với `QuanLySinhVien`; không sử dụng `sa` cho phần mềm sản xuất. `trustServerCertificate=true` ở đây chỉ dành cho môi trường học tập với chứng chỉ tự ký; môi trường production nên xác minh chứng chỉ.

### Nếu Java báo `TCP/IP connection to localhost, port 1433 ... Connection refused`

1. Nhấn `Win+R`, chạy `SQLServerManager16.msc` (SQL Server 2022 Configuration Manager).
2. Mở **SQL Server Network Configuration → Protocols for SQLEXPRESS**, bật **TCP/IP → Enabled = Yes**.
3. Trong **TCP/IP → Properties → IP Addresses**, nếu dùng `Listen All=Yes`, kéo xuống **IPAll**: xóa nội dung **TCP Dynamic Ports**, nhập **TCP Port = 1433** (nếu cổng chưa được sử dụng).
4. Vào **SQL Server Services**, khởi động lại **SQL Server (SQLEXPRESS)**.
5. Mở PowerShell và chạy:
   ```powershell
   Test-NetConnection localhost -Port 1433
   ```
   `TcpTestSucceeded : True` cho thấy cổng mạng đang nhận kết nối (không khẳng định tài khoản/database đúng).
6. Nếu server dùng cổng khác, sửa `db.port` đúng với TCP Port của instance. `localhost\SQLEXPRESS` là **tên instance trong SSMS**, không đồng nghĩa với cổng TCP mặc định 1433.

**Các lỗi khác:**

- `Login failed for user 'sa'`: kiểm tra Mixed Mode, tài khoản `sa` đã được bật và mật khẩu đúng.
- `Cannot open database QuanLySinhVien`: chạy lại `sql/01_tao_csdl.sql` hoặc cấp quyền cho login đang dùng.
- `No suitable driver` / `ClassNotFoundException`: mở dự án bằng **Maven Project**, NetBeans → Dependencies → Reload Project/Download Dependencies.
- `config.properties not found`: đảm bảo file cấu hình nằm cùng cấp với `pom.xml` và bạn Run project từ thư mục gốc.
- `DELETE ... FOREIGN KEY`: dữ liệu đang được bảng khác tham chiếu. Ví dụ muốn xóa lớp có sinh viên, phải chuyển/xóa sinh viên liên quan trước; muốn xóa sinh viên có điểm, phải xử lý điểm trước. Không nên tùy tiện xóa ràng buộc FK.

## 5. Chạy trên Apache NetBeans

1. Giải nén thư mục `QuanLySinhVien_JavaSwing_SQLServer`.
2. Trong **NetBeans → File → Open Project**, chọn thư mục chứa `pom.xml` (biểu tượng Maven).
3. Chọn **JDK 17 hoặc JDK 21** (Tools → Java Platforms), chờ tải Maven dependencies.
4. Tạo `config.properties` theo bước 4, đảm bảo đã chạy SQL ở SSMS.
5. Nhấn chuột phải vào project → **Clean and Build** (hoặc Build).
6. Nhấn **Run Project (F6)**. Nếu NetBeans hỏi Main Class, chọn `vn.edu.qlsv.App`.
7. Mở cửa sổ chính, nhấn **KIỂM TRA KẾT NỐI SQL SERVER**; sau đó mở 4 form để thao tác.

Có thể chạy từ Terminal khi đã có `mvn` trong PATH:

```bash
mvn clean compile exec:java
```

Trên Windows có sẵn `CHAY_TREN_WINDOWS.bat` (yêu cầu Maven đã cài trong PATH); nếu không có Maven, dùng NetBeans để chạy.

## 6. Quy trình kiểm thử giao diện

1. **Lớp:** Thêm mã mới, sửa tên lớp, tìm theo mã, chọn hàng để xóa thử. Không thể xóa lớp nếu có sinh viên thuộc lớp đó.
2. **Sinh viên:** Chọn mã lớp tồn tại, thêm hồ sơ, tìm bằng họ tên, thay đổi ngày sinh theo `yyyy-MM-dd`, sửa và xóa.
3. **Môn học:** Thêm môn có số tín chỉ > 0, tìm theo tên, sửa, xóa. Nhập tín chỉ 0 để kiểm tra thông báo lỗi.
4. **Điểm:** Chọn sinh viên và môn học, chọn học kỳ, điền năm học và điểm trong 0–10. Thử điểm 11, điểm có >2 chữ số thập phân và nhập trùng khóa để xem thông báo lỗi.
5. Đóng chương trình rồi mở lại: dữ liệu vẫn còn vì lưu trong SQL Server, không phải trong RAM.

## 7. Hướng dẫn upload lên GitHub để nộp

1. Mở https://github.com/new và tạo **Public repository** tên gợi ý `QuanLySinhVien-JavaSwing-SQLServer`.
2. Ở repository mới, dùng **Add file → Upload files** (hoặc liên kết `uploading an existing file`).
3. Chọn các file và thư mục **bên trong thư mục dự án**: `src`, `sql`, `docs`, `pom.xml`, `config.example.properties`, `README.md`, `.gitignore`, và (nếu cần) `CHAY_TREN_WINDOWS.bat`.
4. **KHÔNG chọn `config.properties`**, các thư mục `target/`, `build/`, `dist/` hoặc tệp chứa mật khẩu. `.gitignore` chỉ kiểm soát Git trên máy; **không tự động chặn file bạn kéo thả thủ công lên giao diện web GitHub**.
5. Nhấn **Commit changes**. Mở lại repository, xác minh thấy `src/main/java` và `sql/01_tao_csdl.sql`.
6. Gửi đường dẫn repository lên hệ thống của trường, ví dụ: `https://github.com/username/QuanLySinhVien-JavaSwing-SQLServer`.
7. Thử mở URL ở cửa sổ ẩn danh để chắc chắn giảng viên xem được.

## 8. Cấu trúc thư mục

```text
QuanLySinhVien_JavaSwing_SQLServer/
├── pom.xml                         # Maven: JDK 17 + Microsoft JDBC Driver
├── config.example.properties       # Cấu hình ví dụ KHÔNG có mật khẩu thật
├── config.properties               # Tự tạo trên máy; .gitignore chặn commit bằng Git CLI
├── .gitignore
├── CHAY_TREN_WINDOWS.bat
├── README.md
├── docs/
│   └── THIET_KE_VA_KIEM_THU.md
├── sql/
│   ├── 01_tao_csdl.sql
│   ├── 02_du_lieu_mau.sql
│   └── 03_kiem_tra.sql
└── src/
    ├── main/java/vn/edu/qlsv/
    │   ├── App.java
    │   ├── db/Database.java, Sql.java
    │   ├── util/Validate.java
    │   └── ui/HomeFrame.java, CrudFrame.java, Ui.java,
    │          LopFrame.java, SinhVienFrame.java,
    │          MonHocFrame.java, DiemFrame.java
    └── test/java/vn/edu/qlsv/ValidationSmokeTest.java
```

## 9. Kiểm tra logic đầu vào không cần SQL Server

Sau khi Maven đã biên dịch, có thể chạy bài test thuần Java bằng lệnh tương đương:

```bash
javac -encoding UTF-8 -d target/test-classes -cp target/classes src/test/java/vn/edu/qlsv/ValidationSmokeTest.java
java -cp target/classes:target/test-classes vn.edu.qlsv.ValidationSmokeTest
```

Trên Windows, thay dấu `:` giữa các đường dẫn classpath bằng dấu `;`.

---

**Nguồn thiết kế:** PDF `Document18.pdf` được cung cấp trong yêu cầu đồ án. Dữ liệu trong `02_du_lieu_mau.sql` là ví dụ giả lập phục vụ thao tác kiểm thử, không phải danh sách sinh viên thật.
