@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =====================================================
echo    QUAN LY SINH VIEN - JAVA SWING + SQL SERVER
 echo =====================================================
if not exist config.properties (
    echo Chua co config.properties. Tao tu config.example.properties va nhap mat khau SQL.
    pause
    exit /b 1
)
where mvn >nul 2>nul
if errorlevel 1 (
    echo Khong tim thay Maven trong PATH. Mo thu muc du an bang NetBeans va bam Run.
    pause
    exit /b 1
)
mvn -Dfile.encoding=UTF-8 clean compile exec:java
if errorlevel 1 echo Khong the khoi chay. Xem loi ben tren va README.md
pause
