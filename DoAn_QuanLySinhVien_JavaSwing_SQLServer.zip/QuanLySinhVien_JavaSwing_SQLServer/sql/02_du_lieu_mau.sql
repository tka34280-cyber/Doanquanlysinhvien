/*
  Dữ liệu giả lập để thử phần mềm. Không sử dụng thông tin cá nhân thực tế.
  Chạy SAU sql/01_tao_csdl.sql; an toàn khi chạy nhiều lần (bỏ qua mã đã có).
*/
USE QuanLySinhVien;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.LOP WHERE MaLop='CNTT01')
    INSERT INTO dbo.LOP (MaLop,TenLop,KhoaHoc,NganhHoc)
    VALUES ('CNTT01',N'Công nghệ thông tin 01',N'2024-2028',N'Công nghệ thông tin');
IF NOT EXISTS (SELECT 1 FROM dbo.LOP WHERE MaLop='QTKD01')
    INSERT INTO dbo.LOP (MaLop,TenLop,KhoaHoc,NganhHoc)
    VALUES ('QTKD01',N'Quản trị kinh doanh 01',N'2024-2028',N'Quản trị kinh doanh');

IF NOT EXISTS (SELECT 1 FROM dbo.SINHVIEN WHERE MaSV='SV001')
    INSERT INTO dbo.SINHVIEN (MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,MaLop)
    VALUES ('SV001',N'Nguyễn Văn An','2005-01-12',N'Nam',N'Hà Nội','0900000001','CNTT01');
IF NOT EXISTS (SELECT 1 FROM dbo.SINHVIEN WHERE MaSV='SV002')
    INSERT INTO dbo.SINHVIEN (MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,MaLop)
    VALUES ('SV002',N'Trần Thị Bình','2005-03-20',N'Nữ',N'Bắc Ninh','0900000002','CNTT01');
IF NOT EXISTS (SELECT 1 FROM dbo.SINHVIEN WHERE MaSV='SV003')
    INSERT INTO dbo.SINHVIEN (MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,MaLop)
    VALUES ('SV003',N'Lê Minh Châu','2004-11-08',N'Khác',N'Hải Phòng',NULL,'QTKD01');
IF NOT EXISTS (SELECT 1 FROM dbo.SINHVIEN WHERE MaSV='SV004')
    INSERT INTO dbo.SINHVIEN (MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,MaLop)
    VALUES ('SV004',N'Phạm Hoàng Dũng','2005-07-04',N'Nam',N'Hà Nam','0900000004','CNTT01');

IF NOT EXISTS (SELECT 1 FROM dbo.MONHOC WHERE MaMH='MH001')
    INSERT INTO dbo.MONHOC (MaMH,TenMH,SoTinChi) VALUES ('MH001',N'Lập trình Java',3);
IF NOT EXISTS (SELECT 1 FROM dbo.MONHOC WHERE MaMH='MH002')
    INSERT INTO dbo.MONHOC (MaMH,TenMH,SoTinChi) VALUES ('MH002',N'Cơ sở dữ liệu',3);
IF NOT EXISTS (SELECT 1 FROM dbo.MONHOC WHERE MaMH='MH003')
    INSERT INTO dbo.MONHOC (MaMH,TenMH,SoTinChi) VALUES ('MH003',N'Toán rời rạc',2);

IF NOT EXISTS (SELECT 1 FROM dbo.DIEM WHERE MaSV='SV001' AND MaMH='MH001' AND HocKy=1 AND NamHoc='2026-2027')
    INSERT INTO dbo.DIEM VALUES ('SV001','MH001',1,'2026-2027',8.50,9.00,8.80);
IF NOT EXISTS (SELECT 1 FROM dbo.DIEM WHERE MaSV='SV001' AND MaMH='MH002' AND HocKy=1 AND NamHoc='2026-2027')
    INSERT INTO dbo.DIEM VALUES ('SV001','MH002',1,'2026-2027',7.50,8.00,7.80);
IF NOT EXISTS (SELECT 1 FROM dbo.DIEM WHERE MaSV='SV002' AND MaMH='MH001' AND HocKy=1 AND NamHoc='2026-2027')
    INSERT INTO dbo.DIEM VALUES ('SV002','MH001',1,'2026-2027',9.00,8.50,8.70);
IF NOT EXISTS (SELECT 1 FROM dbo.DIEM WHERE MaSV='SV004' AND MaMH='MH003' AND HocKy=2 AND NamHoc='2026-2027')
    INSERT INTO dbo.DIEM VALUES ('SV004','MH003',2,'2026-2027',NULL,NULL,NULL);
GO
PRINT N'Đã thêm dữ liệu mẫu (chỉ thêm mã chưa có).';
GO
