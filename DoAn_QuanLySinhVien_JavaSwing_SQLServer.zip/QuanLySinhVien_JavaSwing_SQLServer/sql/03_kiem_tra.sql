-- Lệnh kiểm tra sau khi tạo CSDL và dữ liệu mẫu; chạy bằng SSMS.
USE QuanLySinhVien;
GO
SELECT N'LOP' AS Bang, COUNT(*) AS SoDong FROM dbo.LOP
UNION ALL SELECT N'SINHVIEN', COUNT(*) FROM dbo.SINHVIEN
UNION ALL SELECT N'MONHOC', COUNT(*) FROM dbo.MONHOC
UNION ALL SELECT N'DIEM', COUNT(*) FROM dbo.DIEM;
GO
SELECT sv.MaSV, sv.HoTen, l.TenLop, mh.TenMH, d.HocKy, d.NamHoc,
       d.DiemQuaTrinh, d.DiemThi, d.DiemTongKet
FROM dbo.DIEM d
JOIN dbo.SINHVIEN sv ON sv.MaSV=d.MaSV
JOIN dbo.LOP l ON l.MaLop=sv.MaLop
JOIN dbo.MONHOC mh ON mh.MaMH=d.MaMH
ORDER BY sv.MaSV, mh.MaMH;
GO
-- Xem quan hệ (foreign keys)
SELECT fk.name AS TenKhoaNgoai,
       OBJECT_NAME(fk.parent_object_id) AS BangCon,
       OBJECT_NAME(fk.referenced_object_id) AS BangCha
FROM sys.foreign_keys fk
WHERE fk.parent_object_id IN (OBJECT_ID('dbo.SINHVIEN'), OBJECT_ID('dbo.DIEM'));
GO
