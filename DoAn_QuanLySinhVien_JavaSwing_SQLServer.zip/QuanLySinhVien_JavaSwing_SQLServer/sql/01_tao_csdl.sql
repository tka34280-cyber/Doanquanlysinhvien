/*
  DO AN JAVA SWING - QUAN LY SINH VIEN
  Thiết kế theo Document18.pdf: LOP, SINHVIEN, MONHOC, DIEM.
  Chạy trên SQL Server Management Studio (SSMS) bằng tài khoản có quyền CREATE DATABASE.
  Script không xóa database hoặc dữ liệu hiện có. Dùng GO, vì vậy chạy trong SSMS.
*/
IF DB_ID(N'QuanLySinhVien') IS NULL
BEGIN
    EXEC(N'CREATE DATABASE QuanLySinhVien');
END;
GO
USE QuanLySinhVien;
GO

IF OBJECT_ID(N'dbo.LOP', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.LOP (
        MaLop       VARCHAR(10) NOT NULL,
        TenLop      NVARCHAR(100) NOT NULL,
        KhoaHoc     NVARCHAR(30) NULL,
        NganhHoc    NVARCHAR(100) NULL,
        CONSTRAINT PK_LOP PRIMARY KEY (MaLop)
    );
END;
GO

IF OBJECT_ID(N'dbo.SINHVIEN', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SINHVIEN (
        MaSV        VARCHAR(10) NOT NULL,
        HoTen       NVARCHAR(100) NOT NULL,
        NgaySinh    DATE NULL,
        GioiTinh    NVARCHAR(10) NULL,
        DiaChi      NVARCHAR(200) NULL,
        SoDienThoai VARCHAR(15) NULL,
        MaLop       VARCHAR(10) NOT NULL,
        CONSTRAINT PK_SINHVIEN PRIMARY KEY (MaSV),
        CONSTRAINT FK_SINHVIEN_LOP FOREIGN KEY (MaLop) REFERENCES dbo.LOP(MaLop),
        CONSTRAINT CK_SINHVIEN_GIOITINH CHECK (GioiTinh IS NULL OR GioiTinh IN (N'Nam', N'Nữ', N'Khác'))
    );
END;
GO

IF OBJECT_ID(N'dbo.MONHOC', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MONHOC (
        MaMH       VARCHAR(10) NOT NULL,
        TenMH      NVARCHAR(100) NOT NULL,
        SoTinChi   INT NOT NULL,
        CONSTRAINT PK_MONHOC PRIMARY KEY (MaMH),
        CONSTRAINT CK_MONHOC_SOTINCHI CHECK (SoTinChi > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.DIEM', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DIEM (
        MaSV          VARCHAR(10) NOT NULL,
        MaMH          VARCHAR(10) NOT NULL,
        HocKy         TINYINT NOT NULL,
        NamHoc        VARCHAR(9) NOT NULL,
        DiemQuaTrinh  DECIMAL(4,2) NULL,
        DiemThi       DECIMAL(4,2) NULL,
        DiemTongKet   DECIMAL(4,2) NULL,
        CONSTRAINT PK_DIEM PRIMARY KEY (MaSV, MaMH, HocKy, NamHoc),
        CONSTRAINT FK_DIEM_SINHVIEN FOREIGN KEY (MaSV) REFERENCES dbo.SINHVIEN(MaSV),
        CONSTRAINT FK_DIEM_MONHOC FOREIGN KEY (MaMH) REFERENCES dbo.MONHOC(MaMH),
        CONSTRAINT CK_DIEM_HOCKY CHECK (HocKy BETWEEN 1 AND 3),
        CONSTRAINT CK_DIEM_QUATRINH CHECK (DiemQuaTrinh IS NULL OR DiemQuaTrinh BETWEEN 0 AND 10),
        CONSTRAINT CK_DIEM_THI CHECK (DiemThi IS NULL OR DiemThi BETWEEN 0 AND 10),
        CONSTRAINT CK_DIEM_TONGKET CHECK (DiemTongKet IS NULL OR DiemTongKet BETWEEN 0 AND 10)
    );
END;
GO

PRINT N'Tạo CSDL QuanLySinhVien và 4 bảng (nếu chưa tồn tại) hoàn tất.';
SELECT name AS TenBang FROM sys.tables WHERE name IN (N'LOP',N'SINHVIEN',N'MONHOC',N'DIEM') ORDER BY name;
GO
