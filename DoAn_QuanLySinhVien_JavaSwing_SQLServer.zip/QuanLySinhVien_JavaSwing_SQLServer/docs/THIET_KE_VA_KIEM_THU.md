# Phân tích thiết kế và kiểm thử đồ án Quản lý Sinh viên

## 1. Cơ sở thiết kế

Tài liệu đầu vào: `Document18.pdf` (4 trang): cơ sở dữ liệu **QuanLySinhVien** gồm 4 bảng **LOP**, **SINHVIEN**, **MONHOC**, **DIEM**; có 3 quan hệ FK và khóa chính ghép ở bảng DIEM. Phần mềm giữ tên các bảng, trường và định nghĩa khóa theo tài liệu.

## 2. Mô hình quan hệ

```text
LOP (MaLop PK) 1 ────────── n SINHVIEN (MaSV PK, MaLop FK)
                                      │
                                      │ 1
                                      │
                                      n
DIEM (MaSV FK, MaMH FK, HocKy, NamHoc PK ghép)
                                      n
                                      │
                                      │ 1
MONHOC (MaMH PK) ─────────────────────┘
```

Khóa chính DIEM: **MaSV + MaMH + HocKy + NamHoc**. Mỗi sinh viên có thể có điểm của nhiều môn qua các học kỳ và năm học; mỗi môn có điểm của nhiều sinh viên. Không thể xóa bản ghi cha nếu đã có bản ghi con do ràng buộc FK.

## 3. Biểu mẫu và xử lý

| Form (màn hình JFrame riêng) | Các trường nhập | SQL |
|---|---|---|
| LopFrame | MaLop, TenLop, KhoaHoc, NganhHoc | SELECT, INSERT, UPDATE, DELETE |
| SinhVienFrame | MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SoDienThoai, MaLop | SELECT JOIN LOP, INSERT, UPDATE, DELETE |
| MonHocFrame | MaMH, TenMH, SoTinChi | SELECT, INSERT, UPDATE, DELETE |
| DiemFrame | MaSV, MaMH, HocKy, NamHoc, DiemQuaTrinh, DiemThi, DiemTongKet | SELECT JOIN SINHVIEN + MONHOC, INSERT, UPDATE điểm, DELETE |

Phần tìm kiếm sử dụng `LIKE ?` và tham số `PreparedStatement`. Bảng JTable không cho sửa trực tiếp; nhập và sửa qua form. Dòng đang chọn được hiển thị trên form; mã PK khóa lại khi sửa.

## 4. Ràng buộc kiểm tra dữ liệu

- Mã và các trường NOT NULL không thể bỏ trống; trường `VARCHAR`/`NVARCHAR` được kiểm tra độ dài theo schema.
- `NgaySinh`: ngày hợp lệ theo `yyyy-MM-dd`, có thể bỏ trống.
- `GioiTinh`: chỉ `Nam`, `Nữ`, `Khác` hoặc NULL.
- `SoTinChi`: số nguyên lớn hơn 0.
- `HocKy`: chọn 1, 2 hoặc 3.
- `NamHoc`: định dạng 4 chữ số, dấu gạch ngang, 4 chữ số (ví dụ `2026-2027`).
- Điểm có thể là NULL; nếu nhập, giá trị 0–10, tối đa 2 chữ số thập phân, tương ứng `DECIMAL(4,2)`.
- Dữ liệu trong bảng có khóa ngoại bắt buộc phải tham chiếu tới mã tồn tại.

Tài liệu đầu vào **không quy định hệ số để tính DiemTongKet**; không tự suy diễn trọng số. Mọi điểm do người dùng nhập và hệ thống kiểm tra miền giá trị.

## 5. Công nghệ

- Java 17+; Swing (`JFrame`, `JPanel`, `JTable`, `JScrollPane`, `DefaultTableModel`, `JComboBox`, `JOptionPane`).
- Maven (`pom.xml`), Microsoft JDBC Driver (`mssql-jdbc`), SQL Server Database Engine.
- Tách lớp: UI (`ui`), kết nối và truy cập SQL (`db`), quy tắc kiểm tra dữ liệu (`util`).
- Truy cập dữ liệu bằng `try-with-resources` để đóng Connection/PreparedStatement/ResultSet sau khi dùng.

## 6. Trạng thái kiểm thử

- **Đã kiểm tra:** Biên dịch tất cả lớp Java (`javac --release 17`); 15/15 bài kiểm tra `ValidationSmokeTest` vượt qua.
- **Cần kiểm tra trên máy người dùng:** Kết nối thật tới instance SQL Server, các thao tác CRUD và ràng buộc khóa ngoại trong DB, giao diện trên màn hình Windows/NetBeans.

**Dữ liệu mẫu chỉ để kiểm thử**; các tên/mã trong script được tạo minh họa, không đại diện cho dữ liệu thật của trường.
